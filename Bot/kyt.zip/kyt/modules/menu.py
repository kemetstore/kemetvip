from kyt import *
import subprocess

def count_pattern(pattern):
	cmd = f'grep -c -E "^{pattern}" /etc/xray/config.json'
	count = subprocess.check_output(cmd, shell=True).decode("ascii").strip()
	return int(count) // 2  # Dibagi 2 karena double data

@bot.on(events.NewMessage(pattern=r"(?:.mets|/menu/start)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
		[Button.inline("🌺𝙎𝙨𝙝 𝙊𝙫𝙥𝙣 𝙈𝙖𝙣𝙖𝙜𝙚𝙧🌺","ssh")],
		[Button.inline("🪷𝙑𝙢𝙚𝙨𝙨 𝙈𝙖𝙣𝙖𝙜𝙚𝙧","vmess"),
		 Button.inline("🌹𝙑𝙡𝙚𝙨𝙨 𝙈𝙖𝙣𝙖𝙜𝙚𝙧","vless")],
		[Button.inline("🌷𝙏𝙧𝙤𝙟𝙖𝙣 𝙈𝙖𝙣𝙖𝙜𝙚𝙧","trojan"),
		 Button.inline("🪻𝙎𝙝𝙙𝙬𝙨𝙠 𝙈𝙖𝙣𝙖𝙜𝙚𝙧","shadowsocks")],
		[Button.inline("🖥️𝘾𝙝𝙚𝙘𝙠 𝙑𝙥𝙨 𝙄𝙣𝙛𝙤","info"),
		 Button.inline("🛠️𝙊𝙩𝙝𝙚𝙧 𝙎𝙚𝙩𝙩𝙞𝙣𝙜","setting")],
		[Button.inline("♲𝘽𝙖𝙘𝙠 𝙈𝙚𝙣𝙪♲","start")]
	]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak,lu bukan mets", alert=True)
		except:
			await event.reply("Akses Ditolak,lu bukan mets")
	elif val == "true":
		# SSH account count
		sh = f'cat /etc/passwd | grep "home" | grep "false" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii").strip()

		# Xray JSON counts (dibagi 2 karena format dobel)
		vms = count_pattern("### ")
		vls = count_pattern("#& ")
		trj = count_pattern("#! ")
		sss = count_pattern("#ss# ")

		# VPS info
		sdss = f"cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii").strip().replace('"','')

		ipvps = f"curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii").strip()

		citsy = f"cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii").strip()

		file_path = "/root/Assets/kemetbot.jpg"
		msg = f"""```

▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
⠭⠶⠿🌺 𝙆𝙀𝙈𝙀𝙏 𝙅𝙎 𝙎𝙏𝙊𝙍𝙀 𝙑𝙋𝙉 🌺⠿⠶⠭
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
⼳» 𝗖𝗥𝗘𝗔𝗧𝗢𝗥 : MUHAMAD ILMI
⼳» 𝗢𝗦     : {namaos}
⼳» 𝗖𝗜𝗧𝗬 : {city}
⼳» 𝗗𝗢𝗠𝗔𝗜𝗡 : {DOMAIN}
⼳» 𝗜𝗣 𝗩𝗣𝗦 : {ipsaya}

⼳» 𝚃𝚘𝚝𝚊𝚕 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 𝙲𝚛𝚎𝚊𝚝𝚎𝚍:
⼳» 𝗦𝗦𝗛 𝗢𝗩𝗣𝗡    : {ssh} account
⼳» 𝗫𝗥𝗔𝗬 𝗩𝗠𝗘𝗦𝗦  : {vms} account
⼳» 𝗫𝗥𝗔𝗬 𝗩𝗟𝗘𝗦𝗦  : {vls} account
⼳» 𝗫𝗥𝗔𝗬 𝗧𝗥𝗢𝗝𝗔𝗡 : {trj} account
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
ʟᴇʙɪʜ ʙᴀɪᴋ ɢᴀɢᴀʟ ᴅᴇɴɢᴀɴ ɪᴅᴇ ᴏʀɪɢɪɴᴀʟ, 
ᴅᴀʀɪᴘᴀᴅᴀ ꜱᴜᴋꜱᴇꜱ ᴅᴇɴɢᴀɴ ᴄᴀʀᴀ ɪᴍɪᴛᴀꜱɪ
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
 𝗩𝟱𝗕𝗼𝘁 -𝗠𝗲𝘁𝗦𝗦𝘁𝗼𝗿𝗲 
```"""
		x = await event.edit(msg, file=file_path, buttons=inline)
		if not x:
			await event.reply(msg, file=file_path, buttons=inline)
