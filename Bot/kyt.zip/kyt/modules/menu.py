from telethon import Button, events
from telethon import TelegramClient
import subprocess
import datetime as DT

# Inisialisasi waktu
uptime = DT.datetime.now()

@bot.on(events.NewMessage(pattern=r"(?:.mets|/menu/start)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    # Tombol inline disusun dalam beberapa baris
    inline = [
        [Button.inline("🔍 Cek Nomor", data="cek_nomor"), Button.inline("🎫 Cek Voucher", data="cek_voucher")],
        [Button.inline("💰 CuanKu", data="cuanku"), Button.inline("🎁 Redeem Voucher", data="redeem_voucher")],
        [Button.inline("💬 Saran", data="saran"), Button.inline("🤝 Donasi", data="donasi")],
        [Button.inline("📱 Isimple Indosat", data="isimple_indosat")]
    ]

    # Mendapatkan informasi pengirim
    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak, lu bukan mets", alert=True)
        except:
            await event.reply("Akses Ditolak, lu bukan mets")
        return

    # Ambil data sistem
    ssh = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode().strip()
    vms = count_pattern("### ")
    vls = count_pattern("#& ")
    trj = count_pattern("#! ")
    sss = count_pattern("#ss# ")
    namaos = subprocess.check_output('cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | cut -d= -f2', shell=True).decode().strip().replace('"', '')
    ipsaya = subprocess.check_output('curl -s ipv4.icanhazip.com', shell=True).decode().strip()
    city = subprocess.check_output('cat /etc/xray/city', shell=True).decode().strip()

    file_path = "/root/Assets/kemetbot.jpg"  # Gambar yang ingin ditampilkan
    msg = f"""```

▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
⠭⠶⠿🌺 𝙆𝙀𝙈𝙀𝙏 𝙅𝙎 𝙎𝙏𝙊𝙍𝙀 𝙑𝙋𝙉 🌺⠿⠶⠭
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
⼳» 𝗖𝗥𝗘𝗔𝗧𝗢𝗥 : MUHAMAD ILMI
⼳» 𝗢𝗦     : {namaos}
⼳» 𝗖𝗜𝗧𝗬 : {city}
⼳» 𝗗𝗢𝗠𝗔𝗜𝗡 : {DOMAIN}
⼳» 𝗜𝗣 𝗩𝗣𝗦 : {ipsaya}

⼳» 𝚃𝚘𝚝𝚊𝚕 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 𝙲𝚛𝚎𝚊𝚝𝚎𝚍:
⼳» 𝗦𝗦𝗛 𝗢𝗩𝗣𝗡    : {ssh} account
⼳» 𝗫𝗥𝗔𝗬 𝗩𝗠𝗘𝗦𝗦  : {vms} account
⼳» 𝗫𝗥𝗔𝗬 𝗩𝗟𝗘𝗦𝗦  : {vls} account
⼳» 𝗫𝗥𝗔𝗬 𝗧𝗥𝗢𝗝𝗔𝗡 : {trj} account
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
ʟᴇʙɪʜ ʙᴀɪᴋ ɢᴀɢᴀʟ ᴅᴇɴɢᴀɴ ɪᴅᴇ ᴏʀɪɢɪɴᴀʟ, 
ᴅᴀʀɪᴘᴀᴅᴀ ꜱᴜᴋꜱᴇꜱ ᴅᴇɴɢᴀɴ ᴄᴀʀᴀ ɪᴍɪᴛᴀꜱɪ
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
 𝗩𝟱𝗕𝗼𝘁 -𝗠𝗲𝘁𝗦𝗦𝘁𝗼𝗿𝗲 
```"""

    try:
        # Mengedit pesan yang sudah ada dan menambahkan tombol inline
        await event.edit(msg, file=file_path, buttons=inline)
    except:
        # Jika gagal mengedit, kirim pesan dengan tombol inline
        await event.reply(msg, file=file_path, buttons=inline)

# 🔁 Handler untuk tombol Back Menu (data='start')
@bot.on(events.CallbackQuery(data=b'/start'))
async def start(event):
    sender = await event.get_sender()

    if valid(str(sender.id)) == "false":
        await event.answer("Akses Ditolak, lu bukan mets 😎", alert=True)
        return

    file_url = "https://telegra.ph/file/1234567890abcdef.jpg"  # Ganti URL banner lo

    start_text = f"""```
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
⠭⠶⠿🌺 𝗞𝗘𝗠𝗘𝗧 𝗝𝗦 𝗦𝗧𝗢𝗥𝗘 𝗩𝗣𝗡 𝗕𝗢𝗧 🌺⠿⠶⠭
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
📆 Aktif Sejak: {uptime.strftime("%d-%m-%Y %H:%M:%S")}
🧑‍💻 Pengguna: {sender.first_name}
🔐 Status:  Authorized

📡 Panel manajemen lengkap:
➤ SSH / OVPN
➤ XRAY Vmess / Vless / Trojan
➤ VPS Monitoring & Info Tools

📲 Gunakan tombol di bawah untuk mengakses menu utama atau menghubungi owner.

📌 Jangan bagikan akun ke orang asing!
```"""

    await event.edit_message(
        file=file_url,
        text=start_text,
        buttons=[
            [Button.inline("📁 Menu Utama", data=b"menu")],
            [Button.url("👤 Owner", "https://t.me/username_owner")]
        ],
        parse_mode="md"
    )