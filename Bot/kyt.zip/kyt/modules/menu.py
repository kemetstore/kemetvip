from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.met|/menu/start)$"))
@bot.on(events.CallbackQuery(data=b'met'))
async def menu(event):
	inline = [
[Button.inline("🌺𝙎𝙨𝙝 𝙊𝙫𝙥𝙣 𝙈𝙖𝙣𝙖𝙜𝙚𝙧🌺","ssh")],
[Button.inline("🪷𝙑𝙢𝙚𝙨𝙨 𝙈𝙖𝙣𝙖𝙜𝙚𝙧","vmess"),
Button.inline("🌹𝙑𝙡𝙚𝙨𝙨 𝙈𝙖𝙣𝙖𝙜𝙚𝙧","vless")],
[Button.inline("🌷𝙏𝙧𝙤𝙟𝙖𝙣 𝙈𝙖𝙣𝙖𝙜𝙚𝙧","trojan"),
Button.inline("🪻𝙎𝙝𝙙𝙬𝙨𝙠 𝙈𝙖𝙣𝙖𝙜𝙚𝙧","shadowsocks")],
[Button.inline("🖥️𝘾𝙝𝙚𝙘𝙠 𝙑𝙥𝙨 𝙄𝙣𝙛𝙤","info"),
Button.inline("🛠️𝙊𝙩𝙝𝙚𝙧 𝙎𝙚𝙩𝙩𝙞𝙣𝙜","setting")],
[Button.inline("♲𝘽𝙖𝙘𝙠 𝙈𝙚𝙣𝙪♲","start")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak,lu bukan mets")
	elif val == "true":
		sh = f' cat /etc/passwd | grep "home" | grep "false" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")
		url = "https://raw.githubusercontent.com/kemetstore/vip/main/limit/kemetbot.jpg"
		msg = f"""

▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
⠭⠶⠿🌺 𝙆𝙀𝙈𝙀𝙏 𝙅𝙎 𝙎𝙏𝙊𝙍𝙀 𝙑𝙋𝙉 🌺⠿⠶⠭
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
⼳» 𝗖𝗥𝗘𝗔𝗧𝗢𝗥 : MUHAMAD ILMI
⼳» 𝗢𝗦     : `{namaos.strip().replace('"','')}`
⼳» 𝗖𝗜𝗧𝗬 : `{city.strip()}`
⼳» 𝗗𝗢𝗠𝗔𝗜𝗡 : `{DOMAIN}`
⼳» 𝗜𝗣 𝗩𝗣𝗦 : `{ipsaya.strip()}`

⼳» 𝚃𝚘𝚝𝚊𝚕 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 𝙲𝚛𝚎𝚊𝚝𝚎𝚍:
⼳» 𝗦𝗦𝗛 𝗢𝗩𝗣𝗡    : {ssh.strip()} account
⼳» 𝗫𝗥𝗔𝗬 𝗩𝗠𝗘𝗦𝗦  : {vms.strip()} account
⼳» 𝗫𝗥𝗔𝗬 𝗩𝗟𝗘𝗦𝗦  : {vls.strip()} account
⼳» 𝗫𝗥𝗔𝗬 𝗧𝗥𝗢𝗝𝗔𝗡 : {trj.strip()} account
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
ʟᴇʙɪʜ ʙᴀɪᴋ ɢᴀɢᴀʟ ᴅᴇɴɢᴀɴ ɪᴅᴇ ᴏʀɪɢɪɴᴀʟ, 
ᴅᴀʀɪᴘᴀᴅᴀ ꜱᴜᴋꜱᴇꜱ ᴅᴇɴɢᴀɴ ᴄᴀʀᴀ ɪᴍɪᴛᴀꜱɪ
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
 𝗩𝟱𝗕𝗼𝘁 -𝗠𝗲𝘁𝗦𝗦𝘁𝗼𝗿𝗲 
"""
		x = await event.edit(msg,file=url,buttons=inline)
		if not x:
			await event.reply(msg,file=url,buttons=inline)


