from kyt import *

@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
    chat = event.chat_id
    sender = await event.get_sender()

    if valid(str(sender.id)) != "true":
        await event.answer("🚫 Akses Ditolak!", alert=True)
        return

    async def create_trojan_(event):
        try:
            async with bot.conversation(chat) as conv:
                await event.respond("**Username:**")
                username = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

                await event.respond("**Quota (GB):**")
                quota_gb = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

                await event.respond("**Limit IP:**")
                limit_ip = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

                await event.respond("**Expired (days):**")
                expired_days = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        except Exception as e:
            await event.respond(
                f"❌ Gagal input data.\n**Detail:** {e}",
                buttons=[[Button.inline("🔙 Menu Utama", data=b"menu")]]
            )
            return

        # Loading animasi
        proses = [
            "Processing.", "Processing..", "Processing...", "Processing....",
            "`Processing Create Premium Account`",
            "`Progress: 0% ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Progress: 20% ██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Progress: 50% ███████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Progress: 100% █████████████████████ `",
            "`Setting up account...`"
        ]
        for p in proses:
            await event.edit(p)
            time.sleep(0.5)

        # Jalankan command
        cmd = f'printf "%s\n" "{username}" "{quota_gb}" "{limit_ip}" "{expired_days}" | bot-add-tro'
        try:
            output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError as e:
            await event.respond(
                f"❌ Gagal membuat akun!\n**Command:** `{e.cmd}`",
                buttons=[[Button.inline("🔙 Menu Utama", data=b"menu")]]
            )
            return

        # Parsing hasil output
        try:
            tro_links = [x.group() for x in re.finditer("trojan://(.*)", output)]
            uuid = re.search("trojan://(.*?)@", tro_links[0]).group(1)
            domain = re.search("@(.*?):", tro_links[0]).group(1)
        except Exception as e:
            await event.respond(f"❌ Parsing link gagal!\n**Detail:** {e}",
                buttons=[[Button.inline("🔙 Menu Utama", data=b"menu")]])
            return

        today = DT.date.today()
        expired_date = today + DT.timedelta(days=int(expired_days))

        # Format output
        msg = f"""
✅ **PREMIUM TROJAN BERHASIL DIBUAT**

⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
🐾🕊️ Xray/Trojan Account 🕊️🐾
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Remarks     : `{username}`
» Host Server : `{domain}`
» Host XrayDNS: `{HOST}`
» User Quota  : `{quota_gb} GB`
» Limit IP    : `{limit_ip}`
» Port DNS    : 443, 53
» Port TLS    : 222-1000
» User ID     : `{uuid}`
» Pub Key     : `{PUB}`
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Link WS    :
`{tro_links[0].strip()}`
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Link GRPC  :
`{tro_links[1].strip()}`
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Format OpenClash:
https://{domain}:81/trojan-{username}.txt
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Expired Until:
`{expired_date}`
"""
        await event.respond(msg, buttons=[[Button.inline("🔙 Menu Utama", data=b"menu")]])

    await create_trojan_(event)
#LOCK trojan
@bot.on(events.CallbackQuery(data=b'lock-trojan'))
async def lock_trojan(event):
	async def lock_trojan_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-lock-tr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{exp}` **Successfully Locked**")
		else:
			msg = f"""**Successfully Locked**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await lock_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
#UNLOCK trojan
@bot.on(events.CallbackQuery(data=b'unlock-trojan'))
async def unlock_trojan(event):
	async def unlock_trojan_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-unlock-tr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{exp}` **Successfully Unlock**")
		else:
			msg = f"""**Successfully Locked**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await unlock_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
@bot.on(events.CallbackQuery(data=b'cek-trojan'))
async def cek_trojan(event):
	async def cek_trojan_(event):
		cmd = 'bot-cek-tr'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**Shows Logged In Users Trojan**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))

    if a != "true":
        await event.answer("🚫 Akses Ditolak!", alert=True)
        return

    async def trial_trojan_(event):
        try:
            async with bot.conversation(chat) as conv:
                await event.respond("**⏳ Durasi trial (menit):**")
                response = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = response.raw_text.strip()
        except Exception as e:
            await event.respond(
                f"❌ Gagal input durasi.\n**Detail:** {e}",
                buttons=[[Button.inline("🔙 Menu Utama", data=b"menu")]]
            )
            return

        # Animasi loading
        steps = [
            "Processing.", "Processing..", "Processing...",
            "`Creating Trial Trojan Account...`"
        ]
        for step in steps:
            await event.edit(step)
            time.sleep(0.5)

        cmd = f'printf "%s\n" "{exp}" | bot-trial-tro'
        try:
            result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
        except subprocess.CalledProcessError as e:
            await bot.send_message(
                chat,
                f"❌ Gagal membuat akun trial Trojan.\n\n**Perintah:** `{cmd}`\n**Error:**\n```{e.output.decode()}```",
                buttons=[[Button.inline("🔙 Menu Utama", data=b"menu")]]
            )
            return

        # Ambil semua link trojan
        links = re.findall(r"trojan://[^\s]+", result)
        if len(links) < 1:
            await bot.send_message(
                chat,
                f"❌ Gagal parsing link Trojan.\n```{result}```",
                buttons=[[Button.inline("🔙 Menu Utama", data=b"menu")]]
            )
            return

        try:
            uuid = re.search(r"trojan://(.*?)@", links[0]).group(1)
            remarks = re.search(r"#(.*)", links[0]).group(1)
            domain = re.search(r"@(.+?):", links[0]).group(1)
        except Exception as e:
            await bot.send_message(
                chat,
                f"❌ Parsing UUID/remarks/domain gagal.\n**Detail:** {e}",
                buttons=[[Button.inline("🔙 Menu Utama", data=b"menu")]]
            )
            return

        expired_dt = DT.datetime.now() + DT.timedelta(minutes=int(exp))
        city = "Indonesia"

        note = f"""⚃┅┅┅┅┅┅┅┅┅┅┅┅⚃  
*_TRIAL BERHASIL_*  
➭ PRODUK : TROJAN  
➭ REGION : {city}  
➭ USER   : {remarks}  
➭ DEVICE : 1 IP  
➭ MASA AKTIF : {exp} MENIT  
⚃┅┅┅┅┅┅┅┅┅┅┅┅⚃  
  *⦋KEMET JS STORE VPN⦌*"""

        msg = f"""
{note}

⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
🐾🕊️ Xray/Trojan Account 🕊️🐾
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Remarks     : `{remarks}`
» Host Server : `{domain}`
» Host XrayDNS: `{HOST}`
» User Quota  : `Unlimited`
» Port DNS    : 443, 53
» Port TLS    : 222-1000
» Path Trojan : /multi path/trojan-ws
» User ID     : `{uuid}`
» Pub Key     : `{PUB}`
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Link WS     :
`{links[0].strip()}`
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Link GRPC   :
`{links[1].strip() if len(links) > 1 else '-'}`
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Expired In  : `{expired_dt.strftime('%Y-%m-%d %H:%M:%S')}`
"""
        await bot.send_message(
            chat,
            msg,
            buttons=[
                [
                    Button.inline("🔁 Trial Lagi", data=b"trial-trojan"),
                    Button.inline("🔙 Menu Utama", data=b"menu")
                ]
            ]
        )

    await trial_trojan_(event)

@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
	async def delete_trojan_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bot-del-tro'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User `{user}` Successfully Deleted**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
	async def trojan_(event):
		inline = [
[Button.inline(" ⏳𝙏𝙍𝙄𝘼𝙇 𝙏𝙍𝙊𝙅𝘼𝙉 ","trial-trojan"),
Button.inline(" 🛒𝘾𝙍𝙀𝘼𝙏𝙀 𝙏𝙍𝙊𝙅𝘼𝙉 ","create-trojan")],
[Button.inline(" 🖥️𝘾𝙃𝙀𝘾𝙆 𝙏𝙍𝙊𝙅𝘼𝙉 ","cek-trojan"),
Button.inline(" ❌𝘿𝙀𝙇𝙀𝙏𝙀 𝙏𝙍𝙊𝙅𝘼𝙉 ","delete-trojan")],
[Button.inline(" 🌀𝙇𝙊𝘾𝙆 𝙏𝙍𝙊𝙅𝘼𝙉 ","lock-trojam"),
Button.inline(" 🌐𝙐𝙉𝙇𝙊𝘾𝙆 𝙏𝙍𝙊𝙅𝘼𝙉 ","unlock-trojan")],
[Button.inline("🔙 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""```
ooo        ooooo               .            
`88.       .888'             .o8            
 888b     d'888   .ooooo.  .o888oo  .oooo.o 
 8 Y88. .P  888  d88' `88b   888   d88(  "8 
 8  `888'   888  888ooo888   888   `"Y88b.  
 8    Y     888  888    .o   888 . o.  )88b 
o8o        o888o `Y8bod8P'   "888" 8""888P'    
╒════════════════════════
│  ⠭⠿☬ TROJAN MANAGER ☬⠿⠭
╞════════════════════════
│♃ » Service: TROJAN
│♃ » Hostname/IP: {DOMAIN}
│♃ » ISP: {z["isp"]}
│♃ » Country: {z["country"]}
╘════════════════════════❐
```"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)
