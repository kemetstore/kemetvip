from kyt import *
import subprocess, re, json, base64, datetime as DT
from telethon import events, Button
import time

# Handler menu utama (.mets)
@bot.on(events.NewMessage(pattern=r"\.mets$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    await event.respond("📋 **Menu Utama**", buttons=[
        [Button.inline("⚙️ Create VMess", b'create-vmess')],
        [Button.inline("🧪 Trial VMess", b'trial-vmess')],
    ])

# CREATE VMESS
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))

    if a != "true":
        return await event.answer("Akses Ditolak", alert=True)

    # Step 1: Input username manual
    await bot.send_message(chat, "**📝 Masukkan Username:**", buttons=[
        [Button.inline("⬅️ Kembali ke Menu", b'menu')]
    ])
    user_msg = await bot.wait_for(events.NewMessage(from_users=sender.id))
    user = user_msg.raw_text

    # Step 2: Pilih Kuota
    quota_buttons = [
        [Button.inline("5 GB", b"quota_5"), Button.inline("10 GB", b"quota_10")],
        [Button.inline("15 GB", b"quota_15"), Button.inline("Unlimited", b"quota_unli")],
        [Button.inline("⬅️ Kembali ke Menu", b'menu')]
    ]
    await bot.send_message(chat, "**📦 Pilih Kuota:**", buttons=quota_buttons)
    quota_event = await bot.wait_for(events.CallbackQuery(from_users=sender.id))
    quota_map = {
        b"quota_5": "5",
        b"quota_10": "10",
        b"quota_15": "15",
        b"quota_unli": "Unlimited"
    }
    pw = quota_map.get(quota_event.data, "5")
    await quota_event.answer(f"Kuota: {pw} GB")

    # Step 3: Pilih Limit-IP
    ip_buttons = [
        [Button.inline("1 IP", b"ip_1"), Button.inline("2 IP", b"ip_2")],
        [Button.inline("3 IP", b"ip_3"), Button.inline("Unlimited", b"ip_unli")],
        [Button.inline("⬅️ Kembali ke Menu", b'menu')]
    ]
    await bot.send_message(chat, "**🌐 Pilih Limit-IP:**", buttons=ip_buttons)
    ip_event = await bot.wait_for(events.CallbackQuery(from_users=sender.id))
    ip_map = {
        b"ip_1": "1",
        b"ip_2": "2",
        b"ip_3": "3",
        b"ip_unli": "Unlimited"
    }
    pw1 = ip_map.get(ip_event.data, "1")
    await ip_event.answer(f"Limit IP: {pw1}")

    # Step 4: Pilih Masa Aktif
    exp_buttons = [
        [Button.inline("1 Hari", b"exp_1"), Button.inline("3 Hari", b"exp_3")],
        [Button.inline("7 Hari", b"exp_7"), Button.inline("30 Hari", b"exp_30")],
        [Button.inline("⬅️ Kembali ke Menu", b'menu')]
    ]
    await bot.send_message(chat, "**⏳ Pilih Masa Aktif (Expired):**", buttons=exp_buttons)
    exp_event = await bot.wait_for(events.CallbackQuery(from_users=sender.id))
    exp_map = {
        b"exp_1": "1",
        b"exp_3": "3",
        b"exp_7": "7",
        b"exp_30": "30"
    }
    exp = exp_map.get(exp_event.data, "1")
    await exp_event.answer(f"Masa aktif: {exp} hari")

    # ✨ Animasi Proses
    await event.edit("`Processing Crate Premium Account`")
    for percent, bar in [
        ("0%", "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
        ("4%", "█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
        ("8%", "██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
        ("20%", "█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
        ("36%", "█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
        ("52%", "█████████████▒▒▒▒▒▒▒▒▒▒▒"),
        ("84%", "█████████████████████▒▒▒▒"),
        ("100%", "█████████████████████████")
    ]:
        await event.edit(f"`Processing... {percent}\n{bar} `")
        time.sleep(0.5)
    await event.edit("`Wait.. Setting up an Account`")

    # Eksekusi backend
    cmd = f'printf "%s\n" "{user}" "{pw}" "{pw1}" "{exp}" | bot-add-vme'
    city = subprocess.check_output("cat /etc/xray/city", shell=True).decode("ascii").strip()
    try:
        output = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except Exception:
        return await event.respond(f"**User** `{user}` **Successfully Created**")

    b = [x.group() for x in re.finditer("vmess://(.*)", output)]
    z = json.loads(base64.b64decode(b[0].replace("vmess://", "")).decode("ascii"))
    z1 = json.loads(base64.b64decode(b[1].replace("vmess://", "")).decode("ascii"))

    today = DT.date.today()
    later = today + DT.timedelta(days=int(exp))

    msg = f"""
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**🌐 Xray/Vmess Account 🌐**
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{z["add"]}`
**» XRAY DNS     :** `{HOST}`
**» User Quota   :** `{pw} GB`
**» Limit IP     :** `{pw1}`
**» Port DNS     :** `443, 53`
**» port TLS     :** `222-1000`
**» Port NTLS    :** `80, 8080, 8081-9999`
**» Port GRPC    :** `443`
**» User ID      :** `{z["id"]}`
**» Path TLS     :** `/multi path/vmess`
**» Path NTLS    :** `/multi path/vmess`
**» ServiceName  :** `vmess-grpc`
**» Pub Key      :** `{PUB}`
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**» Link TLS     :** 
``{b[0].strip()} ``
**» Link NTLS    :** 
``{b[1].strip()} ``
**» OpenClash :** https://{DOMAIN}:81/vmess-{user}.txt
**» Expired Until:** `{later}`
⚃┅┅┅┅┅┅┅┅┅┅┅┅⚃
*_PEMBELIAN BERHASIL_*
➭ PRODUK : VMESS
➭ REGION : {city}
➭ USER   : {user}
➭ DEVICE : {pw1} IP
➭ AKTIF  : {exp} HARI
➭ TGL EXP : {later}
⚃┅┅┅┅┅┅┅┅┅┅┅┅⚃
  *⦋KEMET JS STORE VPN⦌*
"""
    await bot.send_message(chat, msg)

    # 🔙 Tombol kembali ke menu
    await bot.send_message(chat, "🔙 Klik tombol di bawah untuk kembali ke menu:", buttons=[
        [Button.inline("⬅️ Kembali ke Menu", b'menu')]
    ])

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    
    if a != "true":
        await event.answer("🚫 Akses Ditolak!", alert=True)
        return

    async def trial_vmess_(event):
        try:
            async with bot.conversation(chat) as conv:
                await event.respond("**⏳ Durasi trial (menit):**")
                response = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = response.raw_text
        except Exception as e:
            await event.respond(f"❌ Gagal input durasi.\n**Detail:** {e}",
                                buttons=[[Button.inline("🔙 Menu Utama", data=b"menu-utama")]])
            return

        # Animasi loading
        for step in [
            "`Processing.`", "`Processing..`", "`Processing...`", "`Processing....`",
            "`Processing Create Trial Account`",
            "`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Processing... 84%\n█████████████████████▒▒▒▒ `",
            "`Processing... 100%\n█████████████████████████ `",
            "`Wait.. Setting up an Account`"
        ]:
            await event.edit(step)
            time.sleep(0.5)

        cmd = f'printf "%s\n" "{exp}" | bot-trial-vme'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError as e:
            await bot.send_message(
                chat,
                f"❌ Gagal membuat akun trial.\n**Perintah:** `{e.cmd}`\n**Kode Keluar:** {e.returncode}",
                buttons=[[Button.inline("🔙 Menu Utama", data=b"menu")]]
            )
            return

        try:
            today = DT.date.today()
            later = today + DT.timedelta(minutes=int(exp))
            b = [x.group() for x in re.finditer("vmess://(.*)", a)]
            z = json.loads(base64.b64decode(b[0].replace("vmess://", "")).decode("utf-8"))
            z1 = json.loads(base64.b64decode(b[1].replace("vmess://", "")).decode("utf-8"))
        except Exception as e:
            await bot.send_message(
                chat,
                f"❌ Gagal memproses link VMESS.\n**Detail:** {e}",
                buttons=[[Button.inline("🔙 Menu Utama", data=b"menu")]]
            )
            return

        # Tambahan Format Nota
        city = "Indonesia"  # Atau pakai deteksi otomatis jika kamu mau
        note = f"""⚃┅┅┅┅┅┅┅┅┅┅┅┅⚃  
*_TRIAL BERHASIL_*  
➭ PRODUK : VMESS  
➭ REGION : {city}  
➭ USER   : {z["ps"]}  
➭ DEVICE : 1 IP  
➭ MASA AKTIF : {exp} MENIT  
⚃┅┅┅┅┅┅┅┅┅┅┅┅⚃  
  *⦋KEMET JS STORE VPN⦌*"""

        msg = f"""
{note}

⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
🌐 Xray/Vmess Account
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Remarks      : {z["ps"]}
» Domain       : {z["add"]}
» XRAY DNS     : {HOST}
» User Quota   : Unlimited
» Port DNS     : 443, 53
» Port TLS     : 222-1000
» Port NTLS    : 80, 8080, 8081-9999
» Port GRPC    : 443
» User ID      : {z["id"]}
» AlterId      : 0
» Security     : auto
» Network      : (WS) or (gRPC)
» Path TLS     : /multi path/vmess
» Path NLS     : /multi path/vmess
» Path Dynamic : http://BUG.COM
» ServiceName  : vmess-grpc
» Pub Key      : {PUB}
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Link TLS     :
{b[0].strip()}
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Link NTLS    :
{b[1].strip()}
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Format OpenClash :
https://{DOMAIN}:81/vmess-{z["ps"]}.txt
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Expired Until: {later}
"""
        await bot.send_message(
            chat,
            msg,
            buttons=[[Button.inline("🔙 Menu Utama", data=b"menu")]]
        )

    await trial_vmess_(event)
#LOCK VMESS
@bot.on(events.CallbackQuery(data=b'lock-vmess'))
async def lock_vmess(event):
	async def lock_vmess_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-lock-vm'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{exp}` **Successfully Locked**")
		else:
			msg = f"""**Successfully Locked**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await lock_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
#UNLOCK VMESS
@bot.on(events.CallbackQuery(data=b'unlock-vmess'))
async def unlock_vmess(event):
	async def unlock_vmess_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-unlock-vm'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{exp}` **Successfully Unlock**")
		else:
			msg = f"""**Successfully Locked**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await unlock_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
#CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
	async def cek_vmess_(event):
		cmd = 'bot-cek-ws'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**Shows Logged In Users Vmess**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
	async def delete_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bot-del-vme'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Successfully Deleted**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline("⏳𝙏𝙧𝙞𝙖𝙡 𝙑𝙢𝙚𝙨𝙨","trial-vmess"),
Button.inline("🛒𝘾𝙧𝙚𝙖𝙩𝙚 𝙑𝙢𝙚𝙨𝙨","create-vmess")],
[Button.inline("🖥️𝘾𝙝𝙚𝙘𝙠 𝙑𝙢𝙚𝙨𝙨","cek-vmess"),
Button.inline("❌𝘿𝙚𝙡𝙚𝙩𝙚 𝙑𝙢𝙚𝙨𝙨","delete-vmess")],
[Button.inline("🌀𝙇𝙤𝙘𝙠 𝙑𝙢𝙚𝙨𝙨","lock-vmess"),
Button.inline("🌐𝙐𝙣𝙡𝙤𝙘𝙠 𝙑𝙢𝙚𝙨𝙨","unlock-vmess")],
[Button.inline("🔙 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""```
❐════════════════════════❐
    ⠭⠿☬ VMESS MANAGER ☬⠿⠭
❐════════════════════════❐
♃ » Service: VMESS
♃ » Hostname/IP: `{DOMAIN}`
♃ » ISP: `{z["isp"]}`
♃ » Country: `{z["country"]}`
❐════════════════════════❐
```"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)