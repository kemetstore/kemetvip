from kyt import *
from telethon import Button

@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    sender = await event.get_sender()
    chat_id = event.chat_id
    user_id = sender.id

    if valid(str(user_id)) != "true":
        await event.answer("🚫 Akses Ditolak!", alert=True)
        return

    await event.respond("📝 Masukkan Username bro:")
    username_event = await bot.wait_for(events.NewMessage(from_users=user_id))
    username = username_event.raw_text

    await bot.send_message(chat_id, "**📦 Pilih Quota (GB):**", buttons=[
        [Button.inline("1 GB", b"quota_1"), Button.inline("5 GB", b"quota_5")],
        [Button.inline("10 GB", b"quota_10"), Button.inline("Unlimited", b"quota_unlimited")]
    ])

    quota_data = await bot.wait_for(events.CallbackQuery(from_users=user_id))
    quota_map = {
        b"quota_1": "1",
        b"quota_5": "5",
        b"quota_10": "10",
        b"quota_unlimited": "unlimited"
    }
    quota = quota_map[quota_data.data]
    await quota_data.edit(f"📦 Quota dipilih: `{quota}` GB")

    await bot.send_message(chat_id, "**🌐 Pilih Limit IP:**", buttons=[
        [Button.inline("1 IP", b"ip_1"), Button.inline("3 IP", b"ip_3")],
        [Button.inline("5 IP", b"ip_5")]
    ])

    ip_data = await bot.wait_for(events.CallbackQuery(from_users=user_id))
    limit_ip = ip_data.data.decode().split("_")[1]
    await ip_data.edit(f"🌐 Limit IP: `{limit_ip}`")

    await bot.send_message(chat_id, "**📅 Pilih Masa Aktif (Hari):**", buttons=[
        [Button.inline("1 Hari", b"exp_1"), Button.inline("3 Hari", b"exp_3")],
        [Button.inline("7 Hari", b"exp_7"), Button.inline("30 Hari", b"exp_30")]
    ])

    exp_data = await bot.wait_for(events.CallbackQuery(from_users=user_id))
    exp_days = exp_data.data.decode().split("_")[1]
    await exp_data.edit(f"📅 Masa Aktif: `{exp_days} Hari`")

    # Animasi loading
    for text in ["`Processing.`", "`Processing..`", "`Processing...`"]:
        await bot.send_message(chat_id, text)
        time.sleep(0.5)

    try:
        cmd = f'printf "%s\\n" "{username}" "{quota}" "{limit_ip}" "{exp_days}" | bot-add-vme'
        result = subprocess.check_output(cmd, shell=True).decode()
        city = subprocess.check_output("cat /etc/xray/city", shell=True).decode().strip()
    except:
        await bot.send_message(chat_id, "❌ Gagal membuat akun.")
        return

    try:
        links = [x.group() for x in re.finditer("vmess://(.*)", result)]
        z = json.loads(base64.b64decode(links[0].replace("vmess://", "")).decode())
        z1 = json.loads(base64.b64decode(links[1].replace("vmess://", "")).decode())
    except:
        await bot.send_message(chat_id, "❌ Error parsing vmess config.")
        return

    today = DT.date.today()
    expired = today + DT.timedelta(days=int(exp_days))

    msg = f"""
✅ **BERHASIL MEMBUAT AKUN VMESS** ✅

**Remarks** : `{z["ps"]}`
**Domain** : `{z["add"]}`
**Quota** : `{quota} GB`
**Limit IP** : `{limit_ip}`
**Expired** : `{expired}`

🔗 TLS:
`{links[0].strip()}`
🔗 NTLS:
`{links[1].strip()}`
🔗 OpenClash:
https://{DOMAIN}:81/vmess-{username}.txt
"""

    await bot.send_message(chat_id, msg, buttons=[
        [Button.inline("🔁 Create Again", b"create-vmess")],
        [Button.inline("📂 Menu", b"menu")]
    ])

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    
    if a != "true":
        await event.answer("🚫 Akses Ditolak!", alert=True)
        return

    async def trial_vmess_(event):
        try:
            async with bot.conversation(chat) as conv:
                await event.respond("**⏳ Durasi trial (menit):**")
                response = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = response.raw_text
        except Exception as e:
            await event.respond(f"❌ Gagal input durasi.\n**Detail:** {e}",
                                buttons=[[Button.inline("🔙 Menu Utama", data=b"menu-utama")]])
            return

        # Animasi loading
        for step in [
            "`Processing.`", "`Processing..`", "`Processing...`", "`Processing....`",
            "`Processing Create Trial Account`",
            "`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Processing... 84%\n█████████████████████▒▒▒▒ `",
            "`Processing... 100%\n█████████████████████████ `",
            "`Wait.. Setting up an Account`"
        ]:
            await event.edit(step)
            time.sleep(0.5)

        cmd = f'printf "%s\n" "{exp}" | bot-trial-vme'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError as e:
            await bot.send_message(
                chat,
                f"❌ Gagal membuat akun trial.\n**Perintah:** `{e.cmd}`\n**Kode Keluar:** {e.returncode}",
                buttons=[[Button.inline("🔙 Menu Utama", data=b"menu")]]
            )
            return

        try:
            today = DT.date.today()
            later = today + DT.timedelta(minutes=int(exp))
            b = [x.group() for x in re.finditer("vmess://(.*)", a)]
            z = json.loads(base64.b64decode(b[0].replace("vmess://", "")).decode("utf-8"))
            z1 = json.loads(base64.b64decode(b[1].replace("vmess://", "")).decode("utf-8"))
        except Exception as e:
            await bot.send_message(
                chat,
                f"❌ Gagal memproses link VMESS.\n**Detail:** {e}",
                buttons=[[Button.inline("🔙 Menu Utama", data=b"menu")]]
            )
            return

        # Tambahan Format Nota
        city = "Indonesia"  # Atau pakai deteksi otomatis jika kamu mau
        note = f"""⚃┅┅┅┅┅┅┅┅┅┅┅┅⚃  
*_TRIAL BERHASIL_*  
➭ PRODUK : VMESS  
➭ REGION : {city}  
➭ USER   : {z["ps"]}  
➭ DEVICE : 1 IP  
➭ MASA AKTIF : {exp} MENIT  
⚃┅┅┅┅┅┅┅┅┅┅┅┅⚃  
  *⦋KEMET JS STORE VPN⦌*"""

        msg = f"""
{note}

⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
🌐 Xray/Vmess Account
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Remarks      : {z["ps"]}
» Domain       : {z["add"]}
» XRAY DNS     : {HOST}
» User Quota   : Unlimited
» Port DNS     : 443, 53
» Port TLS     : 222-1000
» Port NTLS    : 80, 8080, 8081-9999
» Port GRPC    : 443
» User ID      : {z["id"]}
» AlterId      : 0
» Security     : auto
» Network      : (WS) or (gRPC)
» Path TLS     : /multi path/vmess
» Path NLS     : /multi path/vmess
» Path Dynamic : http://BUG.COM
» ServiceName  : vmess-grpc
» Pub Key      : {PUB}
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Link TLS     :
{b[0].strip()}
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Link NTLS    :
{b[1].strip()}
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Format OpenClash :
https://{DOMAIN}:81/vmess-{z["ps"]}.txt
⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔
» Expired Until: {later}
"""
        await bot.send_message(
            chat,
            msg,
            buttons=[[Button.inline("🔙 Menu Utama", data=b"menu")]]
        )

    await trial_vmess_(event)
#LOCK VMESS
@bot.on(events.CallbackQuery(data=b'lock-vmess'))
async def lock_vmess(event):
	async def lock_vmess_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-lock-vm'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{exp}` **Successfully Locked**")
		else:
			msg = f"""**Successfully Locked**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await lock_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
#UNLOCK VMESS
@bot.on(events.CallbackQuery(data=b'unlock-vmess'))
async def unlock_vmess(event):
	async def unlock_vmess_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-unlock-vm'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{exp}` **Successfully Unlock**")
		else:
			msg = f"""**Successfully Locked**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await unlock_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
#CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
	async def cek_vmess_(event):
		cmd = 'bot-cek-ws'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**Shows Logged In Users Vmess**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
	async def delete_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bot-del-vme'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Successfully Deleted**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline("⏳𝙏𝙧𝙞𝙖𝙡 𝙑𝙢𝙚𝙨𝙨","trial-vmess"),
Button.inline("🛒𝘾𝙧𝙚𝙖𝙩𝙚 𝙑𝙢𝙚𝙨𝙨","create-vmess")],
[Button.inline("🖥️𝘾𝙝𝙚𝙘𝙠 𝙑𝙢𝙚𝙨𝙨","cek-vmess"),
Button.inline("❌𝘿𝙚𝙡𝙚𝙩𝙚 𝙑𝙢𝙚𝙨𝙨","delete-vmess")],
[Button.inline("🌀𝙇𝙤𝙘𝙠 𝙑𝙢𝙚𝙨𝙨","lock-vmess"),
Button.inline("🌐𝙐𝙣𝙡𝙤𝙘𝙠 𝙑𝙢𝙚𝙨𝙨","unlock-vmess")],
[Button.inline("🔙 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""```
❐════════════════════════❐
    ⠭⠿☬ VMESS MANAGER ☬⠿⠭
❐════════════════════════❐
♃ » Service: VMESS
♃ » Hostname/IP: `{DOMAIN}`
♃ » ISP: `{z["isp"]}`
♃ » Country: `{z["country"]}`
❐════════════════════════❐
```"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)